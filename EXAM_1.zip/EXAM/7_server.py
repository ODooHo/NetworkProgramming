from socket import *
import random
import struct
import binascii

port = 9999

sock = socket(AF_INET,SOCK_STREAM)

sock.bind(('',port))
sock.listen(10)
conn,addr = sock.accept()

while True:
    data = conn.recv(1024).decode()
    if data == 'hello':
        s_id = random.randint(1,50000)
        r_id = random.randint(1,50000)
        lumi = random.randint(1,100)
        humi = random.randint(1,100)
        temp = random.randint(1,100)
        air = random.randint(1,100)
        seq = random.randint(1,100000)

        packed = b''
        packed += struct.pack('!HH',s_id,r_id)
        packed += struct.pack('!BBBB',lumi,humi,temp,air)
        packed += struct.pack('!I',seq)

        conn.send(packed)
    else:
        break


