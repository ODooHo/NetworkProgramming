from socket import *
import struct

port = 9999

sock = socket(AF_INET,SOCK_STREAM)

sock.connect(('localhost',port))

while True:
    msg = input("Say Hello:")
    sock.send(msg.encode())

    data = sock.recv(1024)

    data = struct.unpack('!HHBBBBI',data)
    print(f"Sender:{data[0]}, Receiver:{data[1]}, Lumi:{data[2]}, Humi:{data[3]}, Temp:{data[4]}, Air:{data[5]}, Seq:{data[6]}")
