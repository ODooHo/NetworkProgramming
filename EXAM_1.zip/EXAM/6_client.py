from socket import *
import time

port = 7777
BUFFSIZE = 1024
sock = socket(AF_INET,SOCK_DGRAM)
sock.connect(('localhost',port))

time_1 = 1
counter = 0
while True:
    msg = input('Enter a message: ')
    if msg == 'q':
        break
    while True:
        sock.send(msg.encode())
        timer_start = time.time()
        sock.settimeout(time_1)
        try:
            data, addr = sock.recvfrom(BUFFSIZE)
        except timeout:
            counter+=1
            if counter > 2:
                print("Fail")
                counter = 0
                break
        else:
            timer_end = time.time()
            timer = timer_end - timer_start

            print('Sucess : (RTT: {})'.format(timer))
            break
            

sock.close()