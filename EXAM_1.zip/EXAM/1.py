str = 'Hello, IoT'
print(str+str+str)
print(str[:4])
print(str[-4:])
print(str.lower())
print(str[::-1])
