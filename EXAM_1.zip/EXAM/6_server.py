from socket import *
import random

port = 7777
BUFFSIZE = 1024


sock = socket(AF_INET,SOCK_DGRAM)
sock.bind(('',port))

while True:
    msg,addr = sock.recvfrom(BUFFSIZE)
    temp = msg.decode()
    if temp != 'ping':
        continue
    if random.randint(1,10) <=4:
        continue
    sock.sendto('pong'.encode(),addr)