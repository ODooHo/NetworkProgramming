import socket
import ipaddress

ip = '220.69.189.125'
port = 443

name = socket.getfqdn(ip)
print(name)
protocol = socket.getservbyport(port)
print(protocol)

url =f'{socket.getservbyport(port)}://{name}'
print(url)

temp = socket.inet_aton(ip)
print(temp)