from socket import *
import os
import random
import struct
BUF_SIZE = 1024
LENGTH = 4 # '파일 크기': 4바이트
sock = socket(AF_INET, SOCK_STREAM)
sock.bind(('', 8888))
sock.listen(10)
print('Device1 Activated..')

temperature = 0
humid = 0
bright = 0
conn, addr = sock.accept()
while True:
    msg = conn.recv(BUF_SIZE).decode()
    if msg == "quit":
        print("bye")
        break
    elif msg == "1":
        temperature = random.randint(1,50)
        humid = 0
        bright = 0
        result = temperature.to_bytes(12,'big')
        conn.send(result)
    elif msg == "2":
        temperature = 0
        humid = random.randint(1,100)
        bright = 0
        result = humid.to_bytes(12,'big')
        conn.send(result)
    elif msg == "3":
        temperature = 0
        humid = 0
        bright = random.randint(1,150)
        result = bright.to_bytes(12,'big')
        conn.send(result)
        
