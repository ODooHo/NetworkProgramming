from socket import *

port = 6666
BUFFSIZE = 1024

sock = socket(AF_INET, SOCK_DGRAM)

time = 2
counter = 0
while True:
    msg = input('Enter the message("send mboxId message" or "receive mboxId"):')
    if(msg=='quit'):
        break
    while True:
        sock.sendto(msg.encode(),('localhost',port))
        sock.settimeout(time)
        try:
            data, addr = sock.recvfrom(BUFFSIZE)
        except timeout:
            counter+=1
            if counter > 3:
                print("loss")
                counter = 0
                break
        else:
            print('<- ',data.decode())
            break
