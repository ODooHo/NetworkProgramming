from socket import *
import time
s1 = socket(AF_INET, SOCK_STREAM)
addr1 = ('localhost',8888)

s1.connect(addr1)

while True:
    msg = input('Choose inform:')
    if msg == 'quit':
        s1.send(msg.encode())
        break
    elif msg == '1':
        s1.send(msg.encode())
        data = s1.recv(1024)
        if not data:
            break
        tmp = int.from_bytes(data,'big')
        print(f'Temp = {tmp},Humid = 0, Lumi = 0')
    elif msg == '2':
        s1.send(msg.encode())
        data = s1.recv(1024)
        if not data:
            break
        tmp = int.from_bytes(data,'big')
        print(f'Temp = 0,Humid = {tmp}, Lumi = 0')        
    
    elif msg == '3':
        s1.send(msg.encode())
        data = s1.recv(1024)
        if not data:
            break
        tmp = int.from_bytes(data,'big')
        print(f'Temp = 0,Humid = 0, Lumi = {tmp}')
    else:
        print("Wrong request!")
        continue
s1.close()
