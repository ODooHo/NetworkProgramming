temp = 'https://search.daum.net/search?w=tot&q=bigdata'
result = {}
a,b = temp.split("?")
a,b = b.split("&")
key,value = a.split("=")
result[key] = value
key,value = b.split("=")
result[key] = value
print(result)
result[key] = 'iot'
print(result)